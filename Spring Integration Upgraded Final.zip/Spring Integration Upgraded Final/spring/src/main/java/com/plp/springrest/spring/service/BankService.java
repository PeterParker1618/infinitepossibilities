package com.plp.springrest.spring.service;

import java.util.List;

import com.plp.springrest.spring.bean.Bank;
import com.plp.springrest.spring.bean.Transaction;
import com.plp.springrest.spring.exception.BankException;

public interface BankService 
{	
	public Bank createBankAccount(Bank bank) throws BankException;
	public double balanceEnquiry(int accountId) throws BankException;
	public double moneyDeposit(int accountId,double deposit) throws BankException;
	public double moneyWithdrawl(int accountId,double withdraw) throws BankException;
	public Bank moneyTransfer(int source,int destination,double money) throws BankException;
	public List<Transaction> Statement(long accnum);
}
