package com.plp.springrest.spring.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.plp.springrest.spring.bean.Bank;

public interface BankDao extends JpaRepository<Bank,Integer>
{
	
}
