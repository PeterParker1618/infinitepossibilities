import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  amount: number;
  constructor(private customerService:CustomerServiceService,private show: ShowBalanceComponent) { }
  ngOnInit() {
  }
  depositAmount(accnum,amount){
  this.customerService.depositAmount(accnum,amount).subscribe(data => {
      window.alert('Deposit Successful');
      this.amount=this.show.showBalance(accnum);
    });
 }
}
