package dao;

import java.util.HashMap;

import Exception.EmployeeException;
import bean.Employee;

public interface EmployeeDao {
	public void insertEmployee(Employee emp);

    public HashMap<Integer,Employee>getAllEmployees() throws EmployeeException;

    public Employee getEmployeeById(int id)throws EmployeeException;

    
    
    
    

}
