package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import Exception.EmployeeException;
import bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	
 private static HashMap<Integer,Employee> hm = new HashMap<Integer,Employee>();
 
 public static void setMap(HashMap<Integer,Employee> hm) 
 {
	 EmployeeDaoImpl.hm = hm;
 }
 public static HashMap<Integer,Employee> getMap()
 {
       return hm;
 }
 
 public void insertEmployee(Employee e) 
 {
	 hm.put(e.getId(), e);
	 System.out.println("added successfully" +hm);
 }


 public HashMap<Integer, Employee> getAllEmployees()throws EmployeeException {
	if (hm.isEmpty()) 
	{
		throw new EmployeeException();
	}
	else 
	{
	Iterator <Entry<Integer,Employee>> i = hm.entrySet().iterator(); 
	while(i.hasNext()) 
	{
		HashMap.Entry<Integer, Employee> object = (HashMap.Entry<Integer,Employee>)i.next();
		System.out.println(object.getKey()+" = "+object.getValue());
	}
	}
	
	return null;
}

public Employee getEmployeeById(int id) throws EmployeeException {
	if (hm.isEmpty()) {
		throw new EmployeeException("NO Employee With the ID");
	}
	if(hm.containsKey(id)) 
	{
		Employee e = hm.get(id);
		System.out.println("the details are" +e);
	}
	else 
	{
		System.out.println("create acount first:");	
	}
	
	return null;
}
public List<Employee> list(){
	List<Employee> l = new ArrayList<Employee>();
	Set<Integer> s = hm.keySet();
	Iterator<Integer> i = s.iterator();
	while(i.hasNext()) {
		l.add(hm.get(i.next()));
	}
	return l;
}
}
