package Exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		
		System.out.println("No Employee Found");
		
	}
	public EmployeeException(String obj) 
	{
		System.out.println(obj);	
	}
}
