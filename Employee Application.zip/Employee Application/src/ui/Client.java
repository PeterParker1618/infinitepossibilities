package ui;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import com.util.SortByName;

import Exception.EmployeeException;
import bean.Employee;
import service.EmployeeServiceImpl;

public class Client {

	public static void main(String args[]){
		int ch;
		EmployeeServiceImpl s = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
		 System.out.println("Enter Your Choice: \n 1. add details \n 2. retrieve all employee deatails \n 3. retrieve by id \n 4.exit");
	     sc = new Scanner(System.in);
		 ch = sc.nextInt();
		switch(ch) {
		case 1:
			
			String name;
			do {
			System.out.println("Enter the name");
			name = sc.next();
			}while(!s.nameCheck(name));
			
			
			System.out.println("Enter id:");
			int id = sc.nextInt();
			
			int salary;
			do {
			System.out.println("Enter salary:");
			salary = sc.nextInt();
		    }while(!s.salaryCheck(salary));
			
			Employee e = new Employee(name , id , salary);
			s.insertEmployee(e);
			break;
		case 2:
			try {
				s.getAllEmployees();
			} catch (EmployeeException e1) {
				System.out.println(e1);
			}
			break;
		case 3:
			System.out.println("Enter id:");
			sc = new Scanner(System.in);
			int id1 = sc.nextInt();
			try {
				s.getEmployeeById(id1);
			} catch (EmployeeException e1) {
				System.out.println("No Employee found with the ID");;
			}
			break;
		case 4:
			System.out.println("END");
			System.exit(0);
		case 5:
			List l = s.list();
			Collections.sort(l,new SortByName());
			System.out.println(l);
			break;
		}
	}while(ch!=6);
		sc.close();
}}
