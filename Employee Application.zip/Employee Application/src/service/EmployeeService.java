package service;

import java.util.HashMap;

import Exception.EmployeeException;
import bean.Employee;

public interface EmployeeService {
	 public void insertEmployee (Employee emp);

     public HashMap<Integer,Employee>getAllEmployees()throws EmployeeException ;

     public Employee getEmployeeById(int id)throws EmployeeException;

}
