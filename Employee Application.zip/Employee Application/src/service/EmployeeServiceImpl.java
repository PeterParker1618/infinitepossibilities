package service;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import Exception.EmployeeException;
import bean.Employee;
import dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDaoImpl d = new EmployeeDaoImpl();
	public void insertEmployee (Employee e) {
		d.insertEmployee(e);
	}

    public HashMap<Integer,Employee>getAllEmployees() throws EmployeeException {
    	
		return d.getAllEmployees();
    	
    }

    public Employee getEmployeeById(int id)  throws EmployeeException
    {
		return d.getEmployeeById(id);
    	
    }
    
    public boolean nameCheck(String str) {
    	boolean b = false;
    	if(Pattern.matches("([A-Z])*([a-z])*",str) && str.length()>3 && Character.isUpperCase(str.charAt(0)))
    	{
    	System.out.println("Valid Name:" +str);
    	b=true;
    	}else {
    		System.out.println("Invalid Name");
    	}
    	return b;
    	
    	}
    public boolean salaryCheck(int sal) {
    	boolean b = false;
    	while(true){
    	if(sal>0) {
    		System.out.println("valid salary:" +sal);
    		b=true;
    	}else {
    		System.out.println("Invalid Salary.");
    	}
    	return b;
    }}
public List<Employee> list(){
	return d.list();
}
}
