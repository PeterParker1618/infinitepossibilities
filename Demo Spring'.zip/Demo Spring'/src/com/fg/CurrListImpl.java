package com.fg;

import java.util.ArrayList;

public class CurrListImpl implements CurrencyList {
	
	private ArrayList<String> currList;
	
	public void setCurrList(ArrayList<String> currList) {
		this.currList = currList;
	}

	public ArrayList<String> getCurrList(){
		
		return currList;
		
	}

}
