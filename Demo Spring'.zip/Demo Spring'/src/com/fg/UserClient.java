package com.fg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UserClient {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("collection.xml");
		User user = (User) ctx.getBean("user");
		System.out.println(user.getUname());
		System.out.println(user.getPassword());
		// you have 2 containers in spring
		
		// 1st container name: BeanFactory
		// 2nd container name: ApplicationContext
 	    // 3rd point: ApplicationContext is sub Interface for BeanFactory
		// 4th point: why there r 2 containers?
		// BF for basic functionalities.
		// AC container for advanced functionalities.
		// concepts like localization. internationalization, logging, security etc.
	}
}
