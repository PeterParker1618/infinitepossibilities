import { Product } from './Product';
import { Customer } from './Customer';

export class WishItem{

    wishId:string;
    wishedProduct:Product;
    customer:Customer;


}