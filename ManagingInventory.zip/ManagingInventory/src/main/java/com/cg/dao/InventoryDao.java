package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Inventory;

@Repository
public interface InventoryDao  extends JpaRepository<Inventory, Long>{

		@Query("from Inventory where productCategory=:women")
		List<Inventory> viewSimilarProductsByCategory(@Param("women") String women);

		@Query("from Products where productType=:shirt")
		List<Inventory> viewSimilarProductsByType(@Param("shirt") String shirt);

		//List<Products> deleteSimilarProductsByCategory(String men);
		
		@Query("delete from Products where productCategory = ?1")
		List<Inventory> deleteSimilarProductsByCategory(@Param("men") String men);
		

	}

