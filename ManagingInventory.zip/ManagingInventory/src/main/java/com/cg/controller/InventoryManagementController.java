package com.cg.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Inventory;
import com.cg.service.InventoryImpl;

@RestController
public class InventoryManagementController {
	
		@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Product with that Category or Type does not exist.")
		/*@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Customer with this Id is not found")*/
		@ExceptionHandler({Exception.class})
		public void handleException() {
			
		}

		@Autowired
		InventoryImpl inventoryService;
		
		@PostMapping("/addProductDetails")
		public List<Inventory> addProductDetails(@RequestBody Inventory inventory) {
			return inventoryService.addProductDetails(inventory);
		}
		
		@GetMapping("/ViewSimilarProductsByCategory/{women}")
		public List<Inventory> viewSimilarProductsByCategory(@PathVariable String women){
			
			return inventoryService.viewSimilarProductsByCategory(women);
		}
		
		@GetMapping("/ViewSimilarProductsByType/{shirts}")
		public List<Inventory> viewSimilarProductsByType(@PathVariable String shirts){
			return inventoryService.viewSimilarProductsByType(shirts);
		}
		
		@DeleteMapping("/deleteSimilarProductsByCategory/{men}")
		public List<Inventory> deleteSimilarProductsByCategory(@PathVariable String men){
			return inventoryService.deleteSimilarProductsByCategory(men);
		}
	}

}
