package com.cg.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ProductsOneTable")
public class Inventory{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="p")
    @SequenceGenerator(name="P", initialValue=100, allocationSize=1, sequenceName = "p_id")
    /*@Column(name="p_id", updatable=false, nullable=false, length=10)*/
	@Column(name="inventory_id",length=10)
	private long inventoryid;
	@Column(name="inventoryType",length=10)
	private long inventorytype;
	@Column(name="product_id",length=10)
	private long productId;
	@Column(name="name_i",length=70)
	private String name;
	@Column(name="size_i",length=10)
	private String size;
	@Column(name="quantity_i",length=5)	
	private int quantity;
	@Column(name="productType_i",length=100)
	private String productType;
	@Column(name="rating_i",length=5)
	private double rating;
	@Column(name="price_i",length=6)
	private double price;
	@Column(name="productCategory_i",length=100)
	private String productCategory;
	
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Inventory(long inventoryid, long inventorytype, long productId, String name, String size, int quantity,
			String productType, double rating, double price, String productCategory) {
		super();
		this.inventoryid = inventoryid;
		this.inventorytype = inventorytype;
		this.productId = productId;
		this.name = name;
		this.size = size;
		this.quantity = quantity;
		this.productType = productType;
		this.rating = rating;
		this.price = price;
		this.productCategory = productCategory;
	}
	
	public long getInventoryid() {
		return inventoryid;
	}

	public void setInventoryid(long inventoryid) {
		this.inventoryid = inventoryid;
	}

	public long getInventorytype() {
		return inventorytype;
	}

	public void setInventorytype(long inventorytype) {
		this.inventorytype = inventorytype;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Products [productId=" + productId + ", name=" + name + ", size=" + size + ", quantity=" + quantity
				+ ", productType=" + productType + ", rating=" + rating + ", price=" + price + ", productCategory="
				+ productCategory + "]";
	}

}

