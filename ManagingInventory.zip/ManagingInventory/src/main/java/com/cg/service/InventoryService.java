package com.cg.service;

import java.util.List;

import com.cg.bean.Inventory;

public interface InventoryService {
	
	public List<Inventory> viewSimilarProductsByCategory(String women);

	public List<Inventory> addProductDetails(Inventory inventory);

	public List<Inventory> viewSimilarProductsByType(String shirts);

	public List<Inventory> deleteSimilarProductsByCategory(String men);
}
