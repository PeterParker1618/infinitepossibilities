package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Inventory;
import com.cg.dao.InventoryDao;

@Service
public class InventoryImpl implements InventoryService {

	@Autowired
	InventoryDao inventoryDao;
	
	@Override
	public List<Inventory> addProductDetails(Inventory products) {
		inventoryDao.save(products);
		return inventoryDao.findAll();
	}
	
	@Override
	public List<Inventory> viewSimilarProductsByCategory(String women) {
		return inventoryDao.viewSimilarProductsByCategory(women);
		
	}

	@Override
	public List<Inventory> viewSimilarProductsByType(String shirts) {
		
		return inventoryDao.viewSimilarProductsByType(shirts);
	}

	@Override
	public List<Inventory> deleteSimilarProductsByCategory(String men) {
		return inventoryDao.deleteSimilarProductsByCategory(men);
	}
}