package com.cg.similarproducts.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.similarproducts.bean.Products;

@Repository
public interface ProductsDao extends JpaRepository<Products, Long>{

	@Query("from Products where productCategory=:women")
	List<Products> viewSimilarProductsByCategory(@Param("women") String women);

	@Query("from Products where productType=:shirt")
	List<Products> viewSimilarProductsByType(@Param("shirt") String shirt);

	//List<Products> deleteSimilarProductsByCategory(String men);
	
	@Query("delete from Products where productCategory = ?1")
	List<Products> deleteSimilarProductsByCategory(@Param("men") String men);
	

}
