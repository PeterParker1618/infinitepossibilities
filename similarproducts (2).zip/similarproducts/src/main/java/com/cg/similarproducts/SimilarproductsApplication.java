package com.cg.similarproducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimilarproductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimilarproductsApplication.class, args);
	}

}
