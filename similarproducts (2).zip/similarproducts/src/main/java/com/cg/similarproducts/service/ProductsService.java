package com.cg.similarproducts.service;

import java.util.List;

import com.cg.similarproducts.bean.Products;

public interface ProductsService {

	public List<Products> viewSimilarProductsByCategory(String women);

	public List<Products> addProductDetails(Products products);

	public List<Products> viewSimilarProductsByType(String shirts);

	public List<Products> deleteSimilarProductsByCategory(String men);

}
