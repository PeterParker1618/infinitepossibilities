package com.cg.similarproducts.exception;

public class ProductsException extends Exception{
	
	public ProductsException() {
		
	}
	public ProductsException(String msg) {
		super(msg);
	}

}
