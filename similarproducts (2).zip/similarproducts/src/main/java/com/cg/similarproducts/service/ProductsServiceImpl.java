package com.cg.similarproducts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.similarproducts.bean.Products;
import com.cg.similarproducts.dao.ProductsDao;

@Service
public class ProductsServiceImpl implements ProductsService {

	@Autowired
	ProductsDao productsDao;
	
	@Override
	public List<Products> addProductDetails(Products products) {
		productsDao.save(products);
		return productsDao.findAll();
	}
	
	@Override
	public List<Products> viewSimilarProductsByCategory(String women) {
		return productsDao.viewSimilarProductsByCategory(women);
		
	}

	@Override
	public List<Products> viewSimilarProductsByType(String shirts) {
		
		return productsDao.viewSimilarProductsByType(shirts);
	}

	@Override
	public List<Products> deleteSimilarProductsByCategory(String men) {
		return productsDao.deleteSimilarProductsByCategory(men);
	}

}
