package com.cg.eis.bean;


public class Order {
	private int id;
	private double price;
	private int quantity;
	private double amount;
	private double charges;
	
	//Write public getters, setters and toString method
}
