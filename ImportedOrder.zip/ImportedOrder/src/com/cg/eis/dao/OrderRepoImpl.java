package com.cg.eis.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Order;

//Relate this class to OrderRepo interface
public class OrderRepoImpl implements OrderRepo{
	// Map to store orders where key->Order:id and value->Order:object
	private static Map<Integer, Order> orderList = new HashMap<>();
	
	public static Map<Integer, Order> getOrderList() {
		return orderList;
	}

	public static void setOrderList(Map<Integer, Order> orderList) {
		OrderRepoImpl.orderList = orderList;
	}

	
	// implement the abstract methods in the interface	
	
}
