package com.cg.eis.ui;

import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.eis.bean.Order;
import com.cg.eis.exception.QuantityException;
import com.cg.eis.service.OrderServiceImpl;
import com.cg.eis.service.Validator;

public class Client {
	
	/*
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		// To take input from user and perform the operations as per the requirement
		//Refer sample input / output given in question description
	}
}
