package com.cg.eis.service;

import com.cg.eis.exception.QuantityException;

public class Validator {
	
//isQuantityValid method validates if the quantity is valid.

      //If yes, return true else, throw QuantityException
	public static boolean isQuantityValid(int quantity) throws QuantityException {
	    
	}

        
 //isPriceValid method validates if the price is valid.

       //If yes, return true else, return false
       public static boolean isPriceValid(double price){
       }
	
}
