package com.cg.eis.service;

import java.util.Collection;

import com.cg.eis.bean.Order;
import com.cg.eis.dao.OrderRepoImpl;

//Relate this class to OrderService interface

public class OrderServiceImpl implements OrderService{
	
	// to access the dao services
	OrderRepoImpl dao = new OrderRepoImpl();
	
	// Calculating order amount
	// calculateOrder method should retrieve the price and quantity from order object. 
	// Calculate the amount(based on price and quantity) in INR and
	// return that value
	 
	//public int calculateOrder(Order bean)	
	
	
	//calculateConversionCharges method accepts order amount as parameter 
	//and returns the conversion charge
	
	//public double calculateConversionCharges(double amount) {............}
	
	
	//The object passed to saveOrder method holds id, price and quantity.
	//Transfer order object to dao layer after completing all calculations.
	
	//public int saveOrder(Order bean) { ...... }
		
	
	// return the collections of order by invoking the method in dao layer
	//public Collection<Order> getAllOrders() { ... }
	
}	
